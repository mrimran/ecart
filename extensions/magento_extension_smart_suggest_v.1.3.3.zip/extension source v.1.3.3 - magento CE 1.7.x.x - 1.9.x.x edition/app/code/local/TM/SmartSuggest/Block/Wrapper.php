<?php

class TM_SmartSuggest_Block_Wrapper extends Mage_Core_Block_Template
{
    // dummy class for tm_cache compatibility
}
