<?php

class TM_SuggestPage_Helper_Data extends Mage_Core_Helper_Abstract
{

}