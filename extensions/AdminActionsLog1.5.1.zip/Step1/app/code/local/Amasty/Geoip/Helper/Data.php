<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2015 Amasty (https://www.amasty.com)
 * @package Amasty_Geoip
 */   
class Amasty_Geoip_Helper_Data extends Mage_Core_Helper_Url
{

}
