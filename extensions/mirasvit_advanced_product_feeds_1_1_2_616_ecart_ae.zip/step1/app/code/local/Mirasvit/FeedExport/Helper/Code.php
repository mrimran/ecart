<?php
class Mirasvit_FeedExport_Helper_Code extends Mirasvit_MstCore_Helper_Code
{
    protected $k = "P6TOBI7KEV";
    protected $s = "PFE";
    protected $l = "12394";
    protected $v = "1.1.2";
    protected $b = "616";
    protected $d = "ecart.ae";
}
