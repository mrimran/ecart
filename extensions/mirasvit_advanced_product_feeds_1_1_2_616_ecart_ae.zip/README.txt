Carefully follow the manual for installation, configuration, upgrading and removing the extension from your store https://mirasvit.com/doc/pfe/1.1.2/

You have a free support period till Sep 12, 2015. If you need a help, please, contact our support team https://mirasvit.com/support/.
