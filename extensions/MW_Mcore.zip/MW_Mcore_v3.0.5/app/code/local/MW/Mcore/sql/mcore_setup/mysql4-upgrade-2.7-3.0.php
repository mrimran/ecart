<?php
Mage::getModel('core/config')->saveConfig("mcore/upgraded",1); 
