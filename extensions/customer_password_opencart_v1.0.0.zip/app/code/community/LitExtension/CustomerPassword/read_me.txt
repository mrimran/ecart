Please install the module folowing our Installation Guide:
http://litextension.com/docs/litextension_installation_guide.pdf