<?php
$installer = $this;
$installer->startSetup();
$installer->endSetup();