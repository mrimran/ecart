<?php
/**
 * @project: Base
 * @author : LitExtension
 * @url    : http://litextension.com
 * @email  : litextension@gmail.com
 */

class LitExtension_Base_Helper_Data extends Mage_Core_Helper_Abstract{

}