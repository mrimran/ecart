<?php
class MW_FollowUpEmail_Block_Success extends Mage_Core_Block_Template {

    public function _prepareLayout(){
        parent::_prepareLayout();
    }

}