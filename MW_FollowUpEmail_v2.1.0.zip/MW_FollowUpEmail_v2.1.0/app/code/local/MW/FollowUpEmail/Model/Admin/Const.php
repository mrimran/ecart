<?php
/**
 * Created by PhpStorm.
 * User: kz
 * Date: 12/15/14
 * Time: 2:24 PM
 */

class MW_FollowUpEmail_Model_Admin_Const {
    CONST REPORT_RAGE_LAST_24H = 1;
    CONST REPORT_RAGE_LAST_WEEK = 2; // Last week;
    CONST REPORT_RAGE_LAST_MONTH = 3; // Last month
    CONST REPORT_RAGE_LAST_7DAYS = 4; // Last month
    CONST REPORT_RAGE_LAST_30DAYS = 5;// Last 6 months
    CONST REPORT_RAGE_CURRENT_YEAR = 6; // Current year
    CONST REPORT_RAGE_CUSTOM = 7;
}