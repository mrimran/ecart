<?php include 'security.php' ?>

<html>
<head>
    <title>Secure Acceptance - Payment Form Example</title>
    <link rel="stylesheet" type="text/css" href="payment.css"/>
</head>
<body>
<form id="payment_confirmation" action="https://testsecureacceptance.cybersource.com/pay" method="post"/>
<?php
    //$allowedFields = array('access_key', 'profile_id', 'transaction_uuid', 'unsigned_field_names', 'signed_date_time', 'locale', 'transaction_type', 'reference_number', 'amount', 'currency', 'frontend', 'frontend_cid', 'external_no_cache', 'adminhtml', 'adminhtml_cid');
    //$allowedFields = array('access_key', 'profile_id', 'transaction_uuid', 'unsigned_field_names', 'signed_date_time', 'locale', 'transaction_type', 'reference_number', 'amount', 'currency');
    //$params['signed_field_names'] = "signed_field_names,".implode(",", $allowedFields);
    foreach($_POST as $name => $value) {
	//if(in_array($name, $allowedFields))
            $params[$name] = $value;
    }
    $params['signed_date_time'] = gmdate("Y-m-d\TH:i:s\Z");
/*echo "<pre>";
print_r($params);
echo "</pre>";*/
?>
<fieldset id="confirmation">
    <legend>Review Payment Details</legend>
    <div>
        <?php
            foreach($params as $name => $value) {
                echo "<div>";
                echo "<span class=\"fieldName\">" . $name . "</span><span class=\"fieldValue\">" . $value . "</span>";
                echo "</div>\n";
            }
        ?>
    </div>
</fieldset>
    <?php
        foreach($params as $name => $value) {
            echo "<input type=\"hidden\" id=\"" . $name . "\" name=\"" . $name . "\" value=\"" . $value . "\"/>\n";
        }
        echo "<input type=\"hidden\" id=\"signature\" name=\"signature\" value=\"" . sign($params) . "\"/>\n";
    ?>
<input type="submit" id="submit" value="Confirm"/>
</form>
</body>
</html>
